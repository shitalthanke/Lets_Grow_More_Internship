package com.hari.covid_19app.model

enum class NightMode {
    YES,
    NO,
}
