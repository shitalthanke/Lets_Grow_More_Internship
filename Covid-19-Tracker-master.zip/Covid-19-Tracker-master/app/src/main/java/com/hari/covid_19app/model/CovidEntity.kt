package com.hari.covid_19app.model

interface CovidEntity {
    val id: Int
}