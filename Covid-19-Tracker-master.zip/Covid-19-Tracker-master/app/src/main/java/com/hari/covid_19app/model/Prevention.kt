package com.hari.covid_19app.model

data class Prevention(
    val title: String? = null,
    val description: String? = null,
    val imageUrl: String? = null
)